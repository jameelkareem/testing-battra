#include_next <linux/tracepoint.h>

#ifndef __BACKPORT_LINUX_TRACEPOINT_H
#define __BACKPORT_LINUX_TRACEPOINT_H

#ifndef TRACE_DEFINE_ENUM
#define TRACE_DEFINE_ENUM(a)
#endif

#endif /* __BACKPORT_LINUX_TRACEPOINT_H */
